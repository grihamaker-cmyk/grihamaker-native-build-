# GRIHAMAKER Android App — Upload + Direct WhatsApp Attachment

**असली Android source project, compile-ready (APK नहीं)।** Android Studio (2024.2 या नया) और Android SDK 35 चाहिए।

## Build APK
1. Android Studio में `GRIHAMAKER_AndroidStudio` खोलें।
2. Gradle sync पूरा होने दें (पहली बार इंटरनेट लग सकता है)।
3. `Build > Build Bundle(s) / APK(s) > Build APK(s)` चुनें।
4. APK `app/build/outputs/apk/debug/app-debug.apk` में मिलेगा।
5. Play Store release के लिए अलग से `Generate Signed Bundle / APK` और signing key चाहिए।

## Working flow
`Projects > Drawings & Files > Choose files > Save` — Android system DocumentsUI से PDF / DWG / DXF / render PNG/JPG चुनें।
`Share` पर PDF / DWG / Image WhatsApp को content:// URI से दिया जाएगा; multiple files ZIP में पैक होंगी। WhatsApp खुलने पर receiver चुनकर Send दबाना होगा।

### Data safety / upgrades
यह APK `com.grihamaker.businessmanager` package ID उपयोग करता है, लेकिन Android Studio की default debug signature **पुराने APK से अलग** है। इसलिए यह पहले से इंस्टॉल पुराने ऐप के ऊपर update नहीं होगा। पुराने ऐप को uninstall न करें; अलग signature से update करने पर failure होगा। **पहले बैकअप लें और पुराना डेटा सुरक्षित रखें।** पुराने key से signing चाहिए तो private keystore का उपयोग सुरक्षित रूप से करें, सार्वजनिक रूप से नहीं भेजें।

### Tested status
Project source manually checked. इस environment में Android SDK/Gradle नहीं हैं; actual Android build, upload & WhatsApp device test नहीं हो पाया।

## App icon (GRIHAMAKER logo)
Android launcher icon अब ऐप के मौजूदा GRIHAMAKER logo से बनाया गया है। `res/mipmap-*` में legacy icons, और Android 8+ adaptive launcher icon भी शामिल है। कोई बदलाव किए बिना GitHub workflow से APK build कर सकते हैं।
