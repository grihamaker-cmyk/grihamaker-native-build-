package com.grihamaker.businessmanager;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;
import java.net.URLConnection;

/** Secure read-only content:// endpoint for one-time WhatsApp drawing attachments. */
public class ShareProvider extends ContentProvider {
  private File fileFor(Uri uri) throws FileNotFoundException {
    String fileName=uri.getLastPathSegment();
    if(fileName==null || fileName.isEmpty() || !fileName.equals(fileName.replaceAll("[^a-zA-Z0-9._-]","_"))
       || fileName.equals(".") || fileName.equals(".."))throw new FileNotFoundException("Invalid share URI");
    File file=new File(getContext().getCacheDir(),"gm_exports/"+fileName);
    if(!file.isFile())throw new FileNotFoundException("Missing file");
    return file;
  }
  @Override public boolean onCreate(){return true;}
  @Override public String getType(Uri uri){
    String result=URLConnection.guessContentTypeFromName(uri.getLastPathSegment());
    if(result!=null)return result;
    String name=uri.getLastPathSegment().toLowerCase();
    if(name.endsWith(".dwg"))return "application/acad";
    if(name.endsWith(".dxf"))return "image/vnd.dxf";
    if(name.endsWith(".zip"))return "application/zip";
    return "application/octet-stream";
  }
  @Override public ParcelFileDescriptor openFile(Uri uri,String mode) throws FileNotFoundException {
    if(!"r".equals(mode))throw new FileNotFoundException("Read-only");
    return ParcelFileDescriptor.open(fileFor(uri),ParcelFileDescriptor.MODE_READ_ONLY);
  }
  @Override public Cursor query(Uri uri,String[] projection,String selection,String[] selectionArgs,String sortOrder){
    try {
      File file=fileFor(uri);
      String[] cols=projection!=null?projection:new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE};
      MatrixCursor cursor=new MatrixCursor(cols);
      Object[] values=new Object[cols.length];
      for(int i=0;i<cols.length;i++){
        if(OpenableColumns.DISPLAY_NAME.equals(cols[i]))values[i]=file.getName();
        else if(OpenableColumns.SIZE.equals(cols[i]))values[i]=file.length();
        else values[i]=null;
      }
      cursor.addRow(values);return cursor;
    } catch(FileNotFoundException e){return null;}
  }
  @Override public Uri insert(Uri uri,ContentValues values){throw new UnsupportedOperationException();}
  @Override public int delete(Uri uri,String where,String[] args){throw new UnsupportedOperationException();}
  @Override public int update(Uri uri,ContentValues values,String where,String[] args){throw new UnsupportedOperationException();}
}
