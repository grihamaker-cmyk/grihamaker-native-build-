package com.grihamaker.businessmanager;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
  private static final int FILE_PICKER_REQUEST=4820;
  private WebView webView;
  private ValueCallback<Uri[]> fileCallback;
  private final Object shareLock=new Object();
  private FileOutputStream shareStream;
  private File shareFile;
  private String shareMime="application/octet-stream";

  @Override protected void onCreate(Bundle state) {
    super.onCreate(state);
    webView=new WebView(this);
    webView.setBackgroundColor(0xfff8f8f7);
    setContentView(webView);
    WebSettings settings=webView.getSettings();
    settings.setJavaScriptEnabled(true);
    settings.setDomStorageEnabled(true);
    settings.setDatabaseEnabled(true);
    settings.setAllowFileAccess(true);
    settings.setAllowContentAccess(true);
    settings.setJavaScriptCanOpenWindowsAutomatically(false);
    webView.addJavascriptInterface(new ShareBridge(),"GMAndroid");
    webView.setWebChromeClient(new WebChromeClient() {
      @Override public boolean onShowFileChooser(WebView web, ValueCallback<Uri[]> cb,FileChooserParams params) {
        if(fileCallback!=null)fileCallback.onReceiveValue(null);
        fileCallback=cb;
        Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*"); // allow DWG, DXF, PDF, JPEG, PNG, ZIP and other files
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {startActivityForResult(intent,FILE_PICKER_REQUEST);return true;}
        catch(Exception e) {fileCallback=null;cb.onReceiveValue(null);return false;}
      }
    });
    webView.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){
        Uri uri=request.getUrl();String scheme=uri.getScheme();
        if("file".equalsIgnoreCase(scheme) || "about".equalsIgnoreCase(scheme))return false;
        try { startActivity(new Intent(Intent.ACTION_VIEW,uri)); } catch(Exception ignored){}
        return true;
      }
    });
    webView.loadUrl("file:///android_asset/index.html");
  }

  @Override protected void onActivityResult(int request,int result,Intent data){
    super.onActivityResult(request,result,data);
    if(request!=FILE_PICKER_REQUEST)return;
    if(fileCallback==null)return;
    ValueCallback<Uri[]> callback=fileCallback;fileCallback=null;
    if(result!=RESULT_OK || data==null){callback.onReceiveValue(null);return;}
    List<Uri> picked=new ArrayList<>();
    ClipData clip=data.getClipData();
    if(clip!=null){for(int i=0;i<clip.getItemCount();i++){
       Uri uri=clip.getItemAt(i).getUri(); if(uri!=null)picked.add(uri);
    }}
    if(data.getData()!=null && !picked.contains(data.getData()))picked.add(data.getData());
    callback.onReceiveValue(picked.isEmpty()?null:picked.toArray(new Uri[0]));
  }

  @Override public void onBackPressed(){
    if(webView!=null && webView.canGoBack())webView.goBack();else super.onBackPressed();
  }

  @Override protected void onDestroy(){
    synchronized(shareLock){try {if(shareStream!=null)shareStream.close();}catch(Exception ignored){}}
    super.onDestroy();
  }

  public class ShareBridge {
    @JavascriptInterface public void shareStart(String fileName,String mime) {
      synchronized(shareLock){
        try {
          if(shareStream!=null)shareStream.close();
          shareStream=null;
          String safe=(fileName==null?"drawing":fileName).replaceAll("[^a-zA-Z0-9._-]","_");
          if(safe.isEmpty() || safe.equals(".") || safe.equals(".."))safe="drawing.bin";
          if(safe.length()>120)safe=safe.substring(safe.length()-120);
          File dir=new File(getCacheDir(),"gm_exports");
          if(!dir.exists()&&!dir.mkdirs())throw new IOException("Cannot create share folder");
          shareFile=new File(dir,safe);
          shareMime=(mime==null||mime.isEmpty())?"application/octet-stream":mime;
          shareStream=new FileOutputStream(shareFile,false);
        } catch(Exception e){shareStream=null;throw new RuntimeException(e);}
      }
    }
    @JavascriptInterface public void shareChunk(String base64){
      synchronized(shareLock){
        if(shareStream==null)throw new IllegalStateException("shareStart required");
        try {shareStream.write(Base64.decode(base64,Base64.DEFAULT));}
        catch(Exception e){throw new RuntimeException(e);}
      }
    }
    @JavascriptInterface public void shareFinish(final String description){
      final Uri uri;
      final String mime;
      synchronized(shareLock){
        if(shareStream==null || shareFile==null)throw new IllegalStateException("Nothing to send");
        try {shareStream.flush();shareStream.close();shareStream=null;}
        catch(IOException e){throw new RuntimeException(e);}
        uri=new Uri.Builder().scheme("content").authority(getPackageName()+".shares").appendPath(shareFile.getName()).build();
        mime=shareMime;
      }
      runOnUiThread(()->{
        Intent intent=new Intent(Intent.ACTION_SEND);
        intent.setType(mime);
        intent.putExtra(Intent.EXTRA_STREAM,uri);
        intent.putExtra(Intent.EXTRA_TEXT,description);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.setClipData(ClipData.newRawUri("Drawing",uri));
        // Prefer WhatsApp; choose a different sharing app only if WhatsApp isn't installed.
        try {intent.setPackage("com.whatsapp");startActivity(intent);return;}
        catch(ActivityNotFoundException ignored){}
        try {intent.setPackage("com.whatsapp.w4b");startActivity(intent);return;}
        catch(ActivityNotFoundException ignored){}
        intent.setPackage(null);
        try {startActivity(Intent.createChooser(intent,"Send GRIHAMAKER drawing"));}
        catch(Exception ignored){}
      });
    }
  }
}
